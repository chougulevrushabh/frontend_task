import Sidebar from "../Navigation/Sidebar";
import { Row, Col } from "react-bootstrap";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import React, { useRef } from "react";
import NavbarPage from "../Navigation/Navbar";
import Form from "../components/Form";
import Data from "../components/Data";

export default function Router() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route exact path="/" element={<Form />}></Route>
          <Route exact path="/Data" element={<Data />}></Route>
        </Routes>
      </div>
    </Router>
  );
}
