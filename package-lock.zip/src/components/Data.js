import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import "../CSS/Data.css";
import Form from "../components/Form";

const Data = () => {
  const location = useLocation();
  const formDataList = location.state.formData || [];

  console.log(formDataList)
  const [formDataListDelete, setFormDataListDelete] = useState(formDataList);
  const fields = ["name", "email", "contactNumber", "dateOfBirth"];
  const formDataObject = {};
  formDataList.forEach(({ name, value }) => {
    formDataObject[name] = value;
  });

  const [showModal, setShowModal] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);

  const handleFormSubmit = (formDataArray) => {
    console.log("Form submitted with data: ", formDataArray);
    setShowModal(false);
  };

  const handleEdit = (row) => {
    setSelectedRow(row);
    setShowModal(true);
  };

  const handleToDelete = (formDataObject) => {
    console.log("first",formDataObject)
    formDataObject = {};
    console.log("second",formDataObject)
    // setFormDataListDelete(updatedFormDataList);
    // Implement your delete logic here
    // console.log(Delete button clicked for index ${index});
  };
  // Implement your delete logic here

  const handleModalClose = () => {
    setShowModal(false);
    setSelectedRow(null);
  };

  return (
    <div>
      {showModal == false ? (
        <table className="data-table">
          <thead>
            <tr>
              {fields.map((fieldName) => (
                <th key={fieldName}>{fieldName}</th>
              ))}
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              {fields.map((fieldName, index) => (
                <td key={fieldName}>{formDataList[fieldName]}</td>
              ))}
              <td>
                <button onClick={() => handleEdit(formDataObject)}>Edit</button>
                <button onClick={() => handleToDelete(formDataObject)}>
                  Delete
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      ) : (
        <div className="modal">
          <div className="modal-content">
            {/* <span className="close" onClick={handleModalClose}>
              ×
            </span> */}
            <h2>Edit Row</h2>
            <Form formData={selectedRow} onFormSubmit={handleFormSubmit} />
          </div>
        </div>
      )}
    </div>
  );
};

export default Data;
